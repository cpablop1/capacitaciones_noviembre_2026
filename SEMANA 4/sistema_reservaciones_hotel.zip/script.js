(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const form = $("bookingForm");
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const localDate = (date) => {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  };
  const todayString = localDate(today);
  $("entrada").min = todayString;
  $("salida").min = todayString;
  $("year").textContent = new Date().getFullYear();

  const rates = { Sencilla: 350, Doble: 500, Matrimonial: 550, Suite: 950 };
  const money = (amount) => new Intl.NumberFormat("es-GT", {
    style: "currency", currency: "GTQ", minimumFractionDigits: 2
  }).format(amount);

  const getNights = () => {
    const start = $("entrada").value;
    const end = $("salida").value;
    if (!start || !end) return 0;
    const [sy, sm, sd] = start.split("-").map(Number);
    const [ey, em, ed] = end.split("-").map(Number);
    const a = Date.UTC(sy, sm - 1, sd);
    const b = Date.UTC(ey, em - 1, ed);
    return Math.round((b - a) / 86400000);
  };

  const selectedRoom = () => form.querySelector('input[name="habitacion"]:checked')?.value || "";
  const calculate = () => {
    const nights = getNights();
    const room = selectedRoom();
    const rate = rates[room] || 0;
    const subtotal = nights > 0 && rate ? nights * rate : 0;
    const discount = nights >= 5 ? subtotal * 0.10 : 0;
    const total = subtotal - discount;

    $("estimateEmpty").hidden = Boolean(nights > 0 && room);
    $("liveEstimate").hidden = !(nights > 0 && room);
    if (nights > 0 && room) {
      $("estimateRoom").textContent = room;
      $("estimateNights").textContent = `${nights} ${nights === 1 ? "noche" : "noches"}`;
      $("estimateRate").textContent = money(rate);
      $("estimateSubtotal").textContent = money(subtotal);
      $("estimateDiscount").textContent = discount ? `− ${money(discount)}` : money(0);
      $("estimateTotal").textContent = money(total);
      $("discountHint").textContent = discount
        ? "¡Descuento del 10% aplicado por reservar 5 noches o más!"
        : `Te faltan ${Math.max(0, 5 - nights)} ${5 - nights === 1 ? "noche" : "noches"} para obtener el 10% de descuento.`;
    }
    return { nights, room, rate, subtotal, discount, total };
  };

  const updatePeople = () => {
    const adults = Math.max(0, Number($("adultos").value) || 0);
    const children = Math.max(0, Number($("ninos").value) || 0);
    const total = adults + children;
    $("personas").value = `${total} ${total === 1 ? "persona" : "personas"}`;
  };

  const setError = (id, message) => {
    const error = $(`error-${id}`);
    if (error) error.textContent = message;
    const field = $(id)?.closest(".field");
    if (field) {
      field.classList.toggle("invalid", Boolean(message));
      $(id).setAttribute("aria-invalid", message ? "true" : "false");
    }
  };

  const validate = () => {
    let valid = true;
    const requiredText = (id, label) => {
      const value = $(id).value.trim();
      const message = value ? "" : `Ingresa ${label}.`;
      setError(id, message);
      if (message) valid = false;
    };
    requiredText("nombre", "tu nombre completo");

    const email = $("correo").value.trim();
    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
    setError("correo", emailOk ? "" : (email ? "Ingresa un correo electrónico válido." : "Ingresa tu correo electrónico."));
    if (!emailOk) valid = false;

    const phone = $("telefono").value.trim();
    const phoneOk = /^\d{8}$/.test(phone);
    setError("telefono", phoneOk ? "" : "El teléfono debe contener exactamente 8 dígitos.");
    if (!phoneOk) valid = false;

    const start = $("entrada").value;
    const end = $("salida").value;
    const startDate = start ? new Date(`${start}T00:00:00`) : null;
    const endDate = end ? new Date(`${end}T00:00:00`) : null;
    const startOk = Boolean(startDate && startDate >= today);
    setError("entrada", startOk ? "" : (start ? "No puedes seleccionar una fecha anterior a hoy." : "Selecciona la fecha de entrada."));
    if (!startOk) valid = false;
    const endOk = Boolean(endDate && endDate >= today && startDate && endDate > startDate);
    setError("salida", endOk ? "" : (!end ? "Selecciona la fecha de salida." : "La salida debe ser posterior a la entrada y no puede ser anterior a hoy."));
    if (!endOk) valid = false;

    ["tipoHospedaje", "pago"].forEach((id) => {
      const ok = Boolean($(id).value);
      setError(id, ok ? "" : "Selecciona una opción.");
      if (!ok) valid = false;
    });

    const adults = Number($("adultos").value);
    const children = Number($("ninos").value);
    const adultsOk = Number.isInteger(adults) && adults >= 0 && adults <= 20;
    setError("adultos", adultsOk ? "" : "Ingresa una cantidad válida de adultos (0 a 20).");
    if (!adultsOk) valid = false;
    const childrenOk = Number.isInteger(children) && children >= 0 && children <= 20;
    setError("ninos", childrenOk ? "" : "Ingresa una cantidad válida de niños (0 a 20).");
    if (!childrenOk) valid = false;
    if (adultsOk && childrenOk && adults + children < 1) {
      setError("adultos", "La cantidad total de personas debe ser mayor que cero.");
      valid = false;
    }

    const room = selectedRoom();
    $("error-habitacion").textContent = room ? "" : "Selecciona un tipo de habitación.";
    if (!room) valid = false;
    return valid;
  };

  const row = (label, value, extra = "") =>
    `<div class="summary-row ${extra}"><span>${label}</span><strong>${value}</strong></div>`;

  const buildSummary = () => {
    const cost = calculate();
    const adults = Number($("adultos").value);
    const children = Number($("ninos").value);
    const totalPeople = adults + children;
    const special = $("solicitudes").value.trim() || "Ninguna";
    const content = `
      <div class="summary-group"><h4>Información del cliente</h4>
        ${row("Nombre", escapeHtml($("nombre").value.trim()))}
        ${row("Correo", escapeHtml($("correo").value.trim()))}
        ${row("Teléfono", "+502 " + escapeHtml($("telefono").value.trim()))}
      </div>
      <div class="summary-group"><h4>Detalles de hospedaje</h4>
        ${row("Entrada", formatDate($("entrada").value))}
        ${row("Salida", formatDate($("salida").value))}
        ${row("Habitación", cost.room)}
        ${row("Tipo de hospedaje", $("tipoHospedaje").value)}
        ${row("Adultos / niños", `${adults} / ${children}`)}
        ${row("Total de personas", String(totalPeople))}
        ${row("Noches", String(cost.nights))}
      </div>
      <div class="summary-group"><h4>Preferencias y costos</h4>
        ${row("Método de pago", $("pago").value)}
        ${row("Solicitudes especiales", escapeHtml(special))}
        ${row("Precio por noche", money(cost.rate))}
        ${row("Subtotal", money(cost.subtotal))}
        ${row("Descuento", cost.discount ? `− ${money(cost.discount)} (10%)` : money(0))}
        ${row("Total estimado", money(cost.total), "total")}
      </div>`;
    $("summaryContent").innerHTML = content;
    $("summaryDialog").showModal();
  };

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (char) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[char]);
  }
  function formatDate(value) {
    if (!value) return "—";
    const [y, m, d] = value.split("-");
    return `${d}/${m}/${y}`;
  }

  $("entrada").addEventListener("change", () => {
    const start = $("entrada").value;
    $("salida").min = start && start > todayString ? start : todayString;
    if ($("salida").value && $("salida").value <= start) $("salida").value = "";
    setError("entrada", "");
    setError("salida", "");
    calculate();
  });
  $("salida").addEventListener("change", () => { setError("salida", ""); calculate(); });
  form.querySelectorAll('input[name="habitacion"]').forEach((radio) => radio.addEventListener("change", () => {
    $("error-habitacion").textContent = "";
    calculate();
  }));
  ["adultos", "ninos"].forEach((id) => $(id).addEventListener("input", updatePeople));
  $("telefono").addEventListener("input", (event) => {
    event.target.value = event.target.value.replace(/\D/g, "").slice(0, 8);
  });
  $("solicitudes").addEventListener("input", () => {
    $("charCount").textContent = `${$("solicitudes").value.length} / 500`;
  });

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    $("formNotice").hidden = true;
    if (!validate()) {
      $("formNotice").textContent = "Revisa los campos señalados. Hay información pendiente o incorrecta.";
      $("formNotice").hidden = false;
      const firstInvalid = form.querySelector('[aria-invalid="true"]') || form.querySelector('input[name="habitacion"]:not(:checked)');
      firstInvalid?.focus({ preventScroll: false });
      return;
    }
    buildSummary();
  });

  $("clearBtn").addEventListener("click", () => {
    setTimeout(() => {
      form.querySelectorAll(".field").forEach((field) => field.classList.remove("invalid"));
      form.querySelectorAll(".error").forEach((error) => error.textContent = "");
      form.querySelectorAll('[aria-invalid="true"]').forEach((el) => el.removeAttribute("aria-invalid"));
      $("entrada").min = todayString;
      $("salida").min = todayString;
      $("adultos").value = 1;
      $("ninos").value = 0;
      $("personas").value = "1 persona";
      $("charCount").textContent = "0 / 500";
      $("formNotice").hidden = true;
      calculate();
    }, 0);
  });

  const closeSummary = () => $("summaryDialog").close();
  $("closeDialog").addEventListener("click", closeSummary);
  $("cancelSummary").addEventListener("click", closeSummary);
  $("confirmBooking").addEventListener("click", () => {
    closeSummary();
    const reference = `HA-${Date.now().toString().slice(-8)}`;
    $("bookingReference").textContent = reference;
    $("successMessage").textContent = `Gracias, ${$("nombre").value.trim()}. Tu solicitud de ${selectedRoom().toLowerCase()} para ${getNights()} noches quedó preparada en esta demostración.`;
    $("successDialog").showModal();
  });
  const finish = () => {
    $("successDialog").close();
    form.reset();
    form.querySelectorAll(".error").forEach((error) => error.textContent = "");
    form.querySelectorAll(".field").forEach((field) => field.classList.remove("invalid"));
    $("entrada").min = todayString;
    $("salida").min = todayString;
    $("adultos").value = 1;
    $("ninos").value = 0;
    $("personas").value = "1 persona";
    $("charCount").textContent = "0 / 500";
    $("formNotice").hidden = true;
    calculate();
    window.scrollTo({ top: $("reservar").offsetTop - 20, behavior: "smooth" });
  };
  $("closeSuccess").addEventListener("click", () => $("successDialog").close());
  $("finishBooking").addEventListener("click", finish);
  $("summaryDialog").addEventListener("click", (event) => {
    if (event.target === $("summaryDialog")) closeSummary();
  });
  $("successDialog").addEventListener("click", (event) => {
    if (event.target === $("successDialog")) $("successDialog").close();
  });

  updatePeople();
  calculate();
})();